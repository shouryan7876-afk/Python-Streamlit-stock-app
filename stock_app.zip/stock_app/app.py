import warnings
warnings.filterwarnings("ignore")

from io import BytesIO
from datetime import timedelta

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
import yfinance as yf

from sklearn.ensemble import RandomForestRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


# =========================================================
# PAGE CONFIG
# =========================================================
st.set_page_config(
    page_title="Stock Price Predictor",
    page_icon="📈",
    layout="wide"
)


# =========================================================
# CUSTOM STYLING
# =========================================================
st.markdown(
    """
    <style>
    .main-title {
        font-size: 2.4rem;
        font-weight: 800;
        margin-bottom: 0.2rem;
    }
    .sub-text {
        color: #9aa4b2;
        margin-bottom: 1rem;
    }
    .card {
        padding: 1rem 1.2rem;
        border-radius: 16px;
        background: rgba(255,255,255,0.03);
        border: 1px solid rgba(255,255,255,0.08);
    }
    .small-note {
        color: #9aa4b2;
        font-size: 0.9rem;
    }
    </style>
    """,
    unsafe_allow_html=True
)


# =========================================================
# SESSION STATE
# =========================================================
if "prediction_made" not in st.session_state:
    st.session_state.prediction_made = False

if "last_prediction" not in st.session_state:
    st.session_state.last_prediction = None


# =========================================================
# HELPERS
# =========================================================
def sanitize_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    return df


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    for lag in [1, 2, 3, 5, 7, 10]:
        df[f"Close_Lag_{lag}"] = df["Close"].shift(lag)
        df[f"Volume_Lag_{lag}"] = df["Volume"].shift(lag)

    df["SMA_5"] = df["Close"].rolling(5).mean()
    df["SMA_10"] = df["Close"].rolling(10).mean()
    df["SMA_20"] = df["Close"].rolling(20).mean()
    df["SMA_50"] = df["Close"].rolling(50).mean()

    df["EMA_12"] = df["Close"].ewm(span=12, adjust=False).mean()
    df["EMA_26"] = df["Close"].ewm(span=26, adjust=False).mean()

    df["MACD"] = df["EMA_12"] - df["EMA_26"]
    df["MACD_Signal"] = df["MACD"].ewm(span=9, adjust=False).mean()

    rolling_mean = df["Close"].rolling(20).mean()
    rolling_std = df["Close"].rolling(20).std()
    df["BB_Upper"] = rolling_mean + (2 * rolling_std)
    df["BB_Lower"] = rolling_mean - (2 * rolling_std)

    df["Daily_Return"] = df["Close"].pct_change()
    df["Return_5"] = df["Close"].pct_change(5)
    df["Return_10"] = df["Close"].pct_change(10)

    df["Volatility_5"] = df["Daily_Return"].rolling(5).std()
    df["Volatility_10"] = df["Daily_Return"].rolling(10).std()

    df["High_Low_Spread"] = df["High"] - df["Low"]
    df["Open_Close_Spread"] = df["Open"] - df["Close"]

    delta = df["Close"].diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)

    avg_gain = gain.rolling(14).mean()
    avg_loss = loss.rolling(14).mean()
    rs = avg_gain / avg_loss
    df["RSI_14"] = 100 - (100 / (1 + rs))

    return df


@st.cache_data(show_spinner=False)
def load_data(stock_symbol: str, start_date: str = "2018-01-01", end_date: str = "2026-01-01"):
    data = yf.download(stock_symbol, start=start_date, end=end_date, auto_adjust=True)

    if data.empty:
        return None

    data = sanitize_columns(data)
    data.reset_index(inplace=True)
    data = add_features(data)
    data["Target"] = data["Close"].shift(-1)
    data.dropna(inplace=True)
    data.reset_index(drop=True, inplace=True)

    return data


def get_feature_columns():
    return [
        "Open", "High", "Low", "Close", "Volume",
        "Close_Lag_1", "Close_Lag_2", "Close_Lag_3", "Close_Lag_5", "Close_Lag_7", "Close_Lag_10",
        "Volume_Lag_1", "Volume_Lag_2", "Volume_Lag_3", "Volume_Lag_5", "Volume_Lag_7", "Volume_Lag_10",
        "SMA_5", "SMA_10", "SMA_20", "SMA_50",
        "EMA_12", "EMA_26",
        "MACD", "MACD_Signal",
        "BB_Upper", "BB_Lower",
        "Daily_Return", "Return_5", "Return_10",
        "Volatility_5", "Volatility_10",
        "High_Low_Spread", "Open_Close_Spread",
        "RSI_14"
    ]


@st.cache_resource(show_spinner=False)
def train_models(data: pd.DataFrame, feature_columns):
    X = data[feature_columns]
    y = data["Target"]

    train_size = int(len(data) * 0.8)

    X_train = X.iloc[:train_size]
    X_test = X.iloc[train_size:]

    y_train = y.iloc[:train_size]
    y_test = y.iloc[train_size:]

    test_dates = data["Date"].iloc[train_size:]

    models = {
        "Linear Regression": LinearRegression(),
        "Decision Tree": DecisionTreeRegressor(max_depth=10, random_state=42),
        "Random Forest": RandomForestRegressor(
            n_estimators=400,
            max_depth=18,
            min_samples_split=4,
            min_samples_leaf=2,
            random_state=42,
            n_jobs=-1
        )
    }

    results = []
    predictions = {}

    for name, model in models.items():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

        mae = mean_absolute_error(y_test, y_pred)
        mse = mean_squared_error(y_test, y_pred)
        rmse = np.sqrt(mse)
        r2 = r2_score(y_test, y_pred)

        results.append([name, mae, mse, rmse, r2])
        predictions[name] = y_pred

    results_df = pd.DataFrame(results, columns=["Model", "MAE", "MSE", "RMSE", "R2"])
    best_model_name = results_df.sort_values(by="RMSE").iloc[0]["Model"]
    best_model = models[best_model_name]
    best_pred = predictions[best_model_name]

    return best_model, best_model_name, results_df, y_test, best_pred, test_dates


def get_confidence(r2_value: float) -> float:
    confidence = max(0, min(100, (r2_value + 1) * 50))
    return round(confidence, 2)


def make_recommendation(today_close: float, predicted_close: float):
    diff = predicted_close - today_close
    pct = (diff / today_close) * 100 if today_close != 0 else 0

    if pct > 1.5:
        return "BUY", pct
    elif pct < -1.5:
        return "SELL", pct
    return "HOLD", pct


def load_logo_url(symbol: str) -> str:
    mapping = {
        "AAPL": "https://logo.clearbit.com/apple.com",
        "MSFT": "https://logo.clearbit.com/microsoft.com",
        "GOOGL": "https://logo.clearbit.com/google.com",
        "AMZN": "https://logo.clearbit.com/amazon.com",
        "TSLA": "https://logo.clearbit.com/tesla.com",
        "META": "https://logo.clearbit.com/meta.com",
        "NFLX": "https://logo.clearbit.com/netflix.com",
        "TCS.NS": "https://logo.clearbit.com/tcs.com",
        "INFY.NS": "https://logo.clearbit.com/infosys.com",
        "RELIANCE.NS": "https://logo.clearbit.com/ril.com",
    }
    return mapping.get(symbol.upper(), "https://cdn-icons-png.flaticon.com/512/3135/3135715.png")


def prediction_history_path() -> str:
    return "prediction_history.csv"


def append_history(row_df: pd.DataFrame):
    path = prediction_history_path()
    try:
        old = pd.read_csv(path)
        new_df = pd.concat([old, row_df], ignore_index=True)
        new_df.to_csv(path, index=False)
    except FileNotFoundError:
        row_df.to_csv(path, index=False)


def read_history() -> pd.DataFrame:
    path = prediction_history_path()
    try:
        return pd.read_csv(path)
    except FileNotFoundError:
        return pd.DataFrame()


def dataframe_to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8")


def run_future_forecast(data: pd.DataFrame, feature_columns, model, future_days: int = 7) -> pd.DataFrame:
    future_df = data.copy()
    future_predictions = []
    future_dates = []

    for _ in range(future_days):
        latest_row = future_df.iloc[-1].copy()
        feature_input = latest_row[feature_columns].values.reshape(1, -1)

        next_pred = model.predict(feature_input)[0]
        next_date = latest_row["Date"] + timedelta(days=1)

        new_row = latest_row.copy()
        new_row["Date"] = next_date
        new_row["Open"] = next_pred
        new_row["High"] = next_pred
        new_row["Low"] = next_pred
        new_row["Close"] = next_pred
        new_row["Volume"] = latest_row["Volume"]

        future_df = pd.concat([future_df, pd.DataFrame([new_row])], ignore_index=True)
        future_df = add_features(future_df)

        future_predictions.append(next_pred)
        future_dates.append(next_date)

    return pd.DataFrame({
        "Date": future_dates,
        "Predicted_Close": future_predictions
    })


# =========================================================
# SIDEBAR
# =========================================================
st.sidebar.title("⚙️ Controls")
stock_symbol = st.sidebar.text_input("Stock Symbol", value="AAPL").strip().upper()

data = load_data(stock_symbol)
if data is None:
    st.error("No data found for this stock symbol.")
    st.stop()

feature_columns = get_feature_columns()
best_model, best_model_name, results_df, y_test, best_pred, test_dates = train_models(data, feature_columns)

latest_close = float(data.iloc[-1]["Close"])
latest_volume = float(data.iloc[-1]["Volume"])
logo_url = load_logo_url(stock_symbol)

with st.sidebar.form("prediction_form"):
    st.markdown("### Enter today’s market values")
    user_open = st.number_input("Open Price", value=float(latest_close), min_value=0.0, step=0.1)
    user_high = st.number_input("High Price", value=float(latest_close + 1), min_value=0.0, step=0.1)
    user_low = st.number_input("Low Price", value=float(max(0.0, latest_close - 1)), min_value=0.0, step=0.1)
    user_close = st.number_input("Close Price", value=float(latest_close), min_value=0.0, step=0.1)
    user_volume = st.number_input("Volume", value=float(latest_volume), min_value=0.0, step=1.0)
    predict_clicked = st.form_submit_button("🔮 Predict Next Close")

# HEADER

left, right = st.columns([5, 1])
with left:
    st.markdown(f'<div class="main-title">📈 Premium Stock Predictor</div>', unsafe_allow_html=True)
    st.markdown(
        f'<div class="sub-text">Interactive ML dashboard for <b>{stock_symbol}</b> with premium UI, forecasting, downloads, and history.</div>',
        unsafe_allow_html=True
    )
with right:
    st.image(logo_url, width=90)

m1, m2, m3, m4 = st.columns(4)
m1.metric("Best Model", best_model_name)
m2.metric("Latest Close", f"{latest_close:.2f}")
m3.metric("Rows Used", f"{len(data)}")
m4.metric("Best RMSE", f"{results_df['RMSE'].min():.2f}")

# PREDICTION BLOCK

if predict_clicked:
    latest = data.iloc[-1].copy()
    temp_df = data.copy()

    new_row = latest.copy()
    new_row["Date"] = latest["Date"] + timedelta(days=1)
    new_row["Open"] = user_open
    new_row["High"] = user_high
    new_row["Low"] = user_low
    new_row["Close"] = user_close
    new_row["Volume"] = user_volume

    temp_df = pd.concat([temp_df, pd.DataFrame([new_row])], ignore_index=True)
    temp_df = add_features(temp_df)

    input_row = temp_df.iloc[-1][feature_columns].to_frame().T
    predicted_next_close = float(best_model.predict(input_row)[0])

    best_r2 = float(results_df.loc[results_df["Model"] == best_model_name, "R2"].values[0])
    confidence = get_confidence(best_r2)
    recommendation, pct_change = make_recommendation(user_close, predicted_next_close)

    result_row = pd.DataFrame({
        "Timestamp": [pd.Timestamp.now()],
        "Stock": [stock_symbol],
        "Today_Open": [user_open],
        "Today_High": [user_high],
        "Today_Low": [user_low],
        "Today_Close": [user_close],
        "Today_Volume": [user_volume],
        "Predicted_Next_Close": [predicted_next_close],
        "Expected_Change_Percent": [pct_change],
        "Recommendation": [recommendation],
        "Confidence_Score": [confidence],
        "Best_Model": [best_model_name]
    })

    append_history(result_row)

    st.session_state.prediction_made = True
    st.session_state.last_prediction = {
        "predicted_next_close": predicted_next_close,
        "pct_change": pct_change,
        "recommendation": recommendation,
        "confidence": confidence
    }

if st.session_state.prediction_made and st.session_state.last_prediction is not None:
    p = st.session_state.last_prediction
    st.subheader("✅ Latest Prediction")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Today's Close", f"{user_close:.2f}")
    c2.metric("Predicted Next Close", f"{p['predicted_next_close']:.2f}")
    c3.metric("Expected Change", f"{p['pct_change']:.2f}%")
    c4.metric("Confidence", f"{p['confidence']}%")

    st.info(f"Recommendation: **{p['recommendation']}**")


# =========================================================
# TABS
# =========================================================
tab1, tab2, tab3, tab4, tab5 = st.tabs(
    ["📊 Dashboard", "📈 Forecast (7 Days)", "🧠 Model Analysis", "🕘 Prediction History", "⬇️ Downloads"]
)

with tab1:
    st.subheader("Historical Price Overview")

    fig1, ax1 = plt.subplots(figsize=(12, 5))
    ax1.plot(data["Date"], data["Close"], label="Close")
    ax1.plot(data["Date"], data["SMA_5"], label="SMA 5")
    ax1.plot(data["Date"], data["SMA_20"], label="SMA 20")
    ax1.plot(data["Date"], data["SMA_50"], label="SMA 50")
    ax1.set_title(f"{stock_symbol} Historical Price")
    ax1.set_xlabel("Date")
    ax1.set_ylabel("Price")
    ax1.grid(True)
    ax1.legend()
    st.pyplot(fig1)

    st.subheader("Actual vs Predicted")

    fig2, ax2 = plt.subplots(figsize=(12, 5))
    ax2.plot(test_dates, y_test.values, label="Actual")
    ax2.plot(test_dates, best_pred, label=f"Predicted ({best_model_name})")
    ax2.set_title(f"{stock_symbol} Actual vs Predicted")
    ax2.set_xlabel("Date")
    ax2.set_ylabel("Next Day Close")
    ax2.grid(True)
    ax2.legend()
    st.pyplot(fig2)

with tab2:
    st.subheader("7-Day Forecast")
    forecast_df = run_future_forecast(data, feature_columns, best_model, future_days=7)

    fig3, ax3 = plt.subplots(figsize=(12, 5))
    ax3.plot(data["Date"].tail(90), data["Close"].tail(90), label="Last 90 Days Close")
    ax3.plot(
        forecast_df["Date"],
        forecast_df["Predicted_Close"],
        marker="o",
        label="7-Day Forecast"
    )
    ax3.set_title(f"{stock_symbol} Upcoming 7-Day Forecast")
    ax3.set_xlabel("Date")
    ax3.set_ylabel("Predicted Close")
    ax3.grid(True)
    ax3.legend()
    st.pyplot(fig3)

    st.dataframe(forecast_df, use_container_width=True)

with tab3:
    st.subheader("Model Comparison")
    st.dataframe(results_df, use_container_width=True)

    col_a, col_b = st.columns(2)

    with col_a:
        fig4, ax4 = plt.subplots(figsize=(7, 4))
        ax4.bar(results_df["Model"], results_df["RMSE"])
        ax4.set_title("RMSE by Model")
        ax4.set_ylabel("RMSE")
        ax4.grid(True)
        plt.xticks(rotation=10)
        st.pyplot(fig4)

    with col_b:
        fig5, ax5 = plt.subplots(figsize=(7, 4))
        ax5.bar(results_df["Model"], results_df["R2"])
        ax5.set_title("R² by Model")
        ax5.set_ylabel("R²")
        ax5.grid(True)
        plt.xticks(rotation=10)
        st.pyplot(fig5)

    rf_model = None
    if "Random Forest" in results_df["Model"].values:
        rf_model = RandomForestRegressor(
            n_estimators=400,
            max_depth=18,
            min_samples_split=4,
            min_samples_leaf=2,
            random_state=42,
            n_jobs=-1
        )
        X_all = data[feature_columns]
        y_all = data["Target"]
        rf_model.fit(X_all, y_all)

        fi = pd.DataFrame({
            "Feature": feature_columns,
            "Importance": rf_model.feature_importances_
        }).sort_values("Importance", ascending=False).head(15)

        st.subheader("Top 15 Random Forest Features")
        st.dataframe(fi, use_container_width=True)

        fig6, ax6 = plt.subplots(figsize=(12, 5))
        ax6.bar(fi["Feature"], fi["Importance"])
        ax6.set_title("Top 15 Feature Importances")
        ax6.set_ylabel("Importance")
        ax6.grid(True)
        plt.xticks(rotation=45, ha="right")
        st.pyplot(fig6)

with tab4:
    st.subheader("Prediction History")
    history_df = read_history()

    if history_df.empty:
        st.warning("No predictions saved yet.")
    else:
        st.dataframe(history_df, use_container_width=True)

        st.download_button(
            label="⬇️ Download Prediction History CSV",
            data=dataframe_to_csv_bytes(history_df),
            file_name="prediction_history.csv",
            mime="text/csv"
        )

with tab5:
    st.subheader("Download Center")

    forecast_df = run_future_forecast(data, feature_columns, best_model, future_days=7)
    history_df = read_history()

    d1, d2, d3 = st.columns(3)

    with d1:
        st.download_button(
            label="Download Model Comparison CSV",
            data=dataframe_to_csv_bytes(results_df),
            file_name=f"{stock_symbol.lower()}_model_comparison.csv",
            mime="text/csv"
        )

    with d2:
        st.download_button(
            label="Download 7-Day Forecast CSV",
            data=dataframe_to_csv_bytes(forecast_df),
            file_name=f"{stock_symbol.lower()}_7day_forecast.csv",
            mime="text/csv"
        )

    with d3:
        downloadable_history = history_df if not history_df.empty else pd.DataFrame(
            columns=[
                "Timestamp", "Stock", "Today_Open", "Today_High", "Today_Low", "Today_Close",
                "Today_Volume", "Predicted_Next_Close", "Expected_Change_Percent",
                "Recommendation", "Confidence_Score", "Best_Model"
            ]
        )
        st.download_button(
            label="Download Full Prediction History",
            data=dataframe_to_csv_bytes(downloadable_history),
            file_name="full_prediction_history.csv",
            mime="text/csv"
        )

    st.markdown('<div class="small-note">Tip: Make one prediction first so the history tab has records.</div>', unsafe_allow_html=True)